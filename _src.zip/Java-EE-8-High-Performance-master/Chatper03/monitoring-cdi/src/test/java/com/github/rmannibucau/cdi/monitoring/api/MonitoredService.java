package com.github.rmannibucau.cdi.monitoring.api;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MonitoredService {
    public void iAmMonitored() {
        // no-op
    }
}
